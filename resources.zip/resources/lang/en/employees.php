<?php

return [
    "employee-name" => "Employee name",
    "birthdate" => "Birthdate",
    "position" => "Position",
    "record-civilian" => "Record civilian",
    "address" => "Address",
    "phone" => "Phone",
    "email" => "Email address",
    "salary" => "Salary",
    "pay-by-hour" => "Pay by hour",
    "hours-per-day" => "Hours per day",
    "hour-price" => "Hour price",
    "work-start-day" => "Work start day",
    "work-end-day" => "Work end day",
    "work-status" => "Work status",
    "working" => "Working",
    "he-quit" => "He Quit"
];
