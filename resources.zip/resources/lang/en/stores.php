<?php

return [
    "store-name" => "Store name",
    "store-number" => "Store number",
    "inside-a-branch" => "There is inside a branch ?",
    "edit-store" => "Edit store",
    "show-all-stores" => "Show all stores",
    "delete-store" => "Delete store",
    "inventory-all-stores" => "Inventory all stores",
    "choose-store" => "Choose store",
    "from-store" => "From store",
    "to-store" => "To store",
    "choose-product" => "Choose product",
     'from-store'=>"from-store",
    'to-store'=>"to-store"
];
