<?php

return [
    "bank-name" => "Bank name",
    "bank-balance" => "Bank balance",
    "process-type" => "Process type",
    "process-reason" => "Process reason",
    "balance-before" => "Balance before",
    "balance-after" => "Balance after",
    "admin" => "Admin",
    "record-process" => "Record process",
    "withdraw-bank" => "Withdraw bank",
    "deposit-bank" => "Deposit bank",
];
