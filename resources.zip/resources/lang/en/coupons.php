<?php

return [
    "card-number" => "Card number",
    "discount" => "Discount",
    "expire-date" => "Expire date",
    "section" => "Section"
];
