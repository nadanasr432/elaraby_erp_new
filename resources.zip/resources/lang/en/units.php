<?php

return [
    "unit-name" => "Unit name",
    "update-units" => "Update units"
];
