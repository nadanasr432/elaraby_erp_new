<?php

return [
    "supplier-name" => "Supplier name",
    "assigned-user" => "Assigned user",
    "all-users" => "All users",
    "supplier-notes" => "Supplier notes",
    "supplier-indebtedness" => "Supplier indebtedness",
    "phone-with-code" => "Phone with country code",
    "supplier-address" => "Supplier address",
    "additional-options" => "Additional options",
    "dealing-type" => "Dealing type",
    "supplier data" => "supplier data",
    "choose-type" => "Choose type",
    "supplier-company-name" => "Supplier company name",
    "supplier-nationality" => "Supplier nationality",
    "total-suppliers-indebtedness" => "Total suppliers indebtedness",
    "print-suppliers" => "Print suppliers",
    "customer-import-instructions" => "Customer Import Instructions",
    "search-by-nationality" => "Search by nationality",
    "search-by-type" => "Search by type",
    "purch_num" => "Purchase Order No"

];
