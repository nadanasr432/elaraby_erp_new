<?php

use function PHPSTORM_META\map;

return [
    //clients
    'notes' => 'Notes',
    'list_all_bonds_clients' => 'List All Client Bonds',
    'add_new_client_bonds' => "Add Client Bond",
    'client_name' => "Client Name",
    'account' => "Account",
    'type' => "Type",
    'date' => "Date",
    'amount' => "Amount",
    'choose_client' => "Choose Client Name",
    'edit_client_bond' => "Edit Client Bond",
    'print' => "Print",
    'bond_for_client' => "Bond For Client",
    'back' => "Back",
    
    //suppliers
    'list_all_bonds_suppliers' => 'List All Supplier Bonds',
    'add_new_supplier_bonds' => "Add Supplier Bond",
    'supplier_name' => "Supplier Name",
    'choose_supplier' => "Choose Supplier Name",
    'edit_supplier_bond' => "Edit Supplier Bond",
    'bond_for_supplier' => "Bond of Exchange",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    
    
    
    
    
];
