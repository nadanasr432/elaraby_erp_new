<?php

return [
    "category-name" => "Category name",
    "category-type" => "Category type",
    "show-all-categories" => "Show all categories",
    "edit-category" => "Edit category"
];
