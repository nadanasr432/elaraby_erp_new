<?php

return [
    "know-a-lot-about-us" => "Know a lot about us",
    "the-company-was-founded-in-2010" => "The company was established in 2010 after we provided many distinguished services in the world of accounting software and computers, and we made a mark in more than one Arab country.",
    "this-program-was-designed-to-meet-the-needs-of-the-user" => "This program has been worked on to meet the user's need and add a new concept to the world of accounting and business.",
    "take-a-quick-look-at" => "Take a quick look at",
    "vision-goal-and-mission" => "Vision, goal and mission",
    "we-hope-with-hope-to-include-companies-that-need-to-run-their-business" => "We hope, with hope, to include companies that need to run their work remotely through us, and we seek to be as trustworthy as our previous clients have given us and to bring in new clients, and we plan to be the No. 1 program in the Arab world",
    "honesty-in-dealing-and-respect" => "Honesty in dealing and respect",
    "clarity-and-transparency" => "Clarity and transparency",
    "constant-follow-up-with-our-clients" => "Constant follow-up with our clients",
    "facts-and-figures" => "Facts and Figures",
    "numbers-for-us" => "Numbers for us",
    "the-company-approach-to-dealing-with-companies" => "The method followed by the company in dealing with companies and customers always makes us in the forefront, but the speed in implementing the required and continuous follow-up with customers when they encounter problems is our first priority.",
];
