<?php

return [
    "branche-name" => "Branch name",
    "branche-phone" => "Branch phone",
    "branche-address" => "Branch address",
    "branche-number" => "Branch number",
    "commercial-record" => "Commercial record",
    "show-all-branches" => "Show all branchs",
    "edit-branche" => "Edit branch",
    "delete-branche" => "Delete branch",
];
