<?php

return [
    "subcategory-name" => "Category name",
    "subcategory-type" => "Category type",
    "show-all-subcategories" => "Show all Subcategories",
    "edit-subcategory" => "Edit category",
    "choose-category" => "Choose category"
];
