<?php

return [
    "client-name" => "Client name",
    "assigned-user" => "Assigned user",
    "all-users" => "All users",
    "client-notes" => "Client notes",
    "client-indebtedness" => "Client indebtedness",
    "phone-with-code" => "Phone with country code",
    "client-address" => "Client address",
    "additional-options" => "Additional options",
    "dealing-type" => "Dealing type",
    "choose-type" => "Choose type",
    "client-company-name" => "Client company name",
    "client-nationality" => "Client nationality",
    "total-clients-indebtedness" => "Total clients indebtedness",
    "print-clients" => "Print clients",
    "customer-import-instructions" => "Customer Import Instructions",
    "search-by-nationality" => "Search by nationality",
    "search-by-type" => "Search by type",
];
