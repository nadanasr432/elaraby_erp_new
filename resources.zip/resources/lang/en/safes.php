<?php

return [
    "safe-name" => "Safe name",
    "in-branch" => "There is inside a branch",
    "choose-branch" => "Choose branch",
    "safe-balance" => "Safe balance",
    "safe-type" => "Safe type",
    "safe-number" => "Safe number",
    "notes" => "Notes"
];
