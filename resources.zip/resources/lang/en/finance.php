<?php

return [
    "fixed-expense-statement" => "Fixed expense statement"
];
