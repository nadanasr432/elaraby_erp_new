<?php

return [
    "product-balance-before" => "Product balance before",
    "product-balance-after" => "Product balance after",
    "message" => "Message",
    "subject" => "Subject",
    "attach-files" => "Attach files",
    "choose-product-images" => "Choose product images",
    "click-to-select-products" => "Click to select products",
    "send-message" => "Send message"
];
