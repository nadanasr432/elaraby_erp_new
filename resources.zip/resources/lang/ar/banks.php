<?php

return [
    "bank-name" => "اسم البنك",
    "bank-balance" => "رصيد البنك",
    "process-type" => "نوع العملية",
    "process-reason" => "سبب",
    "balance-before" => "رصيد ما قبل",
    "balance-after" => "رصيد ما بعد",
    "admin" => "المشرف",
    "record-process" => "تسجيل العملية",
    "withdraw-bank" => "بنك السحب",
    "deposit-bank" => "بنك الايداع",
];
