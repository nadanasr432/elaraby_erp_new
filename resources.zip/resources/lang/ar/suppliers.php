<?php

return [
    "supplier-name" => "اسم المورد",
    "assigned-user" => "المستخدم المخصص له",
    "all-users" => "كل المستخدمين",
    "supplier-notes" => "ملاحظات المورد",
    "supplier-indebtedness" => "مديونية المورد",
    "phone-with-code" => "رقم الهاتف بمفتاح الدولة",
    "supplier-address" => "عنوان المورد",
    "additional-options" => "خيارات اضافية",
    "dealing-type" => "فئة التعامل",
    "choose-type" => "اختر فئة",
    "supplier-company-name" => "اسم محل / شركة المورد",
    "supplier-nationality" => "جنسية المورد",
    "total-suppliers-indebtedness" => "اجمالي مديونيات الموردين",
    "print-suppliers" => "طباعه كل الموردين",
    "customer-import-instructions" => "تعليمات استيراد الموردين",
    "search-by-nationality" => "بحث بالجنسية",
    "search-by-type" => "بحث بالفئة",
    "supplier data"=>"بيانات المورد",
    "purch_num" => "رقم امر الشراء"

];
