<?php

return [
    "safe-name" => "اسم الخزينة",
    "in-branch" => "هل توجد بداخل فرع",
    "choose-branch" => "اختر الفرع",
    "safe-balance" => "رصيد الخزينة",
    "safe-type" => "نوع الخزينة",
    "safe-number" => "رقم الخزينة",
    "notes" => "ملاحظات"
];
