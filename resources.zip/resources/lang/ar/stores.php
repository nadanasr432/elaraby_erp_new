<?php

return [
    "store-name" => "اسم المخزن",
    "store-number" => "رقم المخزن",
    "inside-a-branch" => "يوجد بداخل فرع ؟",
    "edit-store" => "تحديث بيانات المخزن",
    "show-all-stores" => "عرض كل المخازن",
    "delete-store" => "حذف مخزن",
    "inventory-all-stores" => "جرد كل المخازن",
    "choose-store" => "اختر المخزن",
    "choose-product" => "اختر المنتج",
      "choose-product" => "اختر المنتج",
    'from-store'=>"من خزنة",
    'to-store'=>"الي خزنة"
];
