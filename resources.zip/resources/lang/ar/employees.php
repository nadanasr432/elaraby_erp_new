<?php

return [
    "employee-name" => "اسم الموظف",
    "birthdate" => "تاريخ الميلاد",
    "position" => "الوظيفة",
    "record-civilian" => "السجل المدني",
    "address" => "العنوان",
    "phone" => "رقم الهاتف",
    "email" => "البريد الالكتروني",
    "salary" => "المرتب",
    "pay-by-hour" => "الدفع بالساعه",
    "hours-per-day" => "عدد الساعات في اليوم",
    "hour-price" => "ثمن الساعه",
    "work-start-day" => "يوم بداية العمل",
    "work-end-day" => "يوم نهاية العمل",
    "work-status" => "حالة العمل",
    "working" => "يعمل",
    "he-quit" => "قدم استقالته"
];
