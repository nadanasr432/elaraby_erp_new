<?php

return [
    "card-number" => "رقم البطاقة",
    "discount" => "قيمة الخصم",
    "expire-date" => "تاريخ انتهاء الصلاحية",
    "section" => "القسم المخصص له"
];
