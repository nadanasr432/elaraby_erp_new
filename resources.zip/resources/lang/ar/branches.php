<?php

return [
    "branche-name" => "اسم الفرع",
    "branche-phone" => "تليفون الفرع",
    "branche-address" => "عنوان الفرع",
    "branche-number" => "رقم الفرع",
    "commercial-record" => "سجل تجاري",
    "show-all-branches" => "عرض كل الفروع",
    "edit-branche" => "تحديث بيانات الفرع",
    "delete-branche" => "حذف فرع"
];
