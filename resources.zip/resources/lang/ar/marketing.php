<?php

return [
    "product-balance-before" => "رصيد المنتج ما قبل",
    "product-balance-after" => "رصيد المنتج ما بعد",
    "message" => "نص الرسالة",
    "subject" => "موضوع الرسالة",
    "attach-files" => "ارفاق ملفات",
    "choose-product-images" => "اختر صور منتجات",
    "click-to-select-products" => "اضغط هنا لاختيار المنتجات",
    "send-message" => "ارسال الرسالة"
];
