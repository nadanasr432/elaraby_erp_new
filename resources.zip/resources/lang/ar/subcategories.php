<?php

return [
    "subcategory-name" => "اسم الفئة",
    "subcategory-type" => "نوع الفئة",
    "show-all-subcategories" => "عرض كل الفئات الفرعية",
    "edit-subcategory" => "تعديل الفئة",
    "choose-category" => "اختر الفئة"
];
