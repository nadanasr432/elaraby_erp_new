<?php

use function PHPSTORM_META\map;

return [
    //clients
    'notes' => 'ملاحظات',
    'list_all_bonds_clients' => 'عرض كل سندات العملاء',
    'add_new_client_bonds' => "اضافة  سندات العملاء",
    'client_name' => "استلمنا من المكرم",
    'account' => "الحساب",
    'type' => "النوع",
    'date' => "التاريخ",
    'amount' => "مبلغ و قدره",
    'choose_client' => "اختر العميل",
    'edit_client_bond' => "تعديل السند الخاص بالعميل",
    'print' => "طباعة",
    'bond_for_client' => "سند قبض",
    'back' => "العودة",
    
    
    
    //suppliers
    'list_all_bonds_suppliers' => 'عرض كل سندات الموردين',
    'add_new_supplier_bonds' => "اضافة  سندات الموردين",
    'supplier_name' => "اسم المورد",
    'choose_supplier' => "اختر المورد",
    'edit_supplier_bond' => "تعديل السند الخاص بالمورد",
    'bond_for_supplier' => "سند صرف",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    '' => "",
    
    
    
    
    
];
