<?php

return [
    'addnewmanufacture' => 'اضافة أمر تصنيع',
    'status' => 'الحالة',
    'choose_status' => 'اختر حالة',
    'processing' => 'تحت التنفيذ',
    'complete' => 'مكتمل',
    'canceled' => 'مرفوض',
    'date' => 'تاريخ',
    'choose_products' => 'اختر منتجات التصنيع',
    'number' => 'رقم التصنيع',
    'store' => 'اسم المخزن',
    'total' => 'القيمة',
    'quantity' => 'الكمية',
    'note' => 'ملاحظة',
    'view' => 'عرض',
    'confirm' => 'تنفيذ التصنيع',
    'cancel' => 'الغاء التصنيع',
    'choose_product' => 'اختر منتج',
    'Product Name' => 'اسم المنتج',
    'Price' => 'سعر منتج',
    'Quantity' => 'الكمية',
    'Action' => 'تحكم',
    'Total Quantity' =>  'اجمالي الكمية',
    'Total' => 'الاجمالي',

];
