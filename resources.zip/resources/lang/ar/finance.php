<?php

return [
    "fixed-expense-statement" => "بيان المصروف الثابت"
];
