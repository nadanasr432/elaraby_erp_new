<?php

return [
    "unit-name" => "اسم الوحدة",
    "update-units" => "تحديث الوحدة"
];
