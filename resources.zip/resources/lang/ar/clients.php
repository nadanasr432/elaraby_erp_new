<?php

return [
    "client-name" => "اسم العميل",
    "assigned-user" => "المستخدم المخصص له",
    "all-users" => "كل المستخدمين",
    "client-notes" => "ملاحظات العميل",
    "client-indebtedness" => "مديونية العميل",
    "phone-with-code" => "رقم الهاتف بمفتاح الدولة",
    "client-address" => "عنوان العميل",
    "additional-options" => "خيارات اضافية",
    "dealing-type" => "فئة التعامل",
    "choose-type" => "اختر فئة",
    "client-company-name" => "اسم محل / شركة العميل",
    "client-nationality" => "جنسية العميل",
    "total-clients-indebtedness" => " مديونية العملاء",
    "print-clients" => "طباعه كل العملاء",
    "customer-import-instructions" => "تعليمات استيراد العملاء",
    "search-by-nationality" => "بحث بالجنسية",
    "search-by-type" => "بحث بالفئة",
];
