<?php

return [
    "category-name" => "اسم الفئة",
    "category-type" => "نوع الفئة",
    "show-all-categories" => "عرض كل الفئات",
    "edit-category" => "تحديث بيانات فئة"
];
