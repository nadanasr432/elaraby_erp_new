<li>
    <a class="pt-2" target="_blank" href="https://play.google.com/store/apps/details?id=com.elaraby.elarabyErp">
        <img src="{{ asset('images/google-play.png') }}" width="50%" alt="google-play">
    </a>
</li>
<li>
    <a class="pt-2" target="_blank" href="https://play.google.com/store/apps/details?id=com.elaraby.elarabyErp">
        <img src="{{ asset('images/app-store.png') }}" width="50%" alt="google-play">
    </a>
</li> */
/* <div class="logo text-center d-flex justify-content-between" style="gap:20px">
    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.elaraby.elarabyErp">
        <img style="width: 40px;height:40px;margin-top: 10px; margin-bottom: 10px;"
            src="{{ asset('images/google-play.png') }}" class="img-fluid" alt="google-play">
    </a>
    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.elaraby.elarabyErp">
        <img style="width: 40px;height:40px;margin-top: 10px; margin-bottom: 10px;"
            src="{{ asset('images/app-store.png') }}" class="img-fluid" alt="app-store">
    </a>



    <br>
</div>
