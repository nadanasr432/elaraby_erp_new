<link href="{{asset('app-assets/css-rtl/bootstrap.css')}}" rel="stylesheet"/>
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/css-rtl/app.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/css-rtl/custom-rtl.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/css-rtl/vertical-menu-modern.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/css-rtl/line-awesome.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/css-rtl/line-awesome-font-awesome.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/css-rtl/style-rtl.css')}}">
<link href="{{asset('app-assets/css-rtl/bootstrap-select.css')}}" rel="stylesheet"/>
<link rel="stylesheet" href="{{asset('app-assets/css-rtl/progress-chart.css')}}">
<style>
    div#DataTables_Table_0_filter {
        text-align: left !important;
        float: left !important;
        display: inline !important;
    }
    div#DataTables_Table_0_length {
        text-align: right !important;
        float: right !important;
        display: inline !important;
    }
    select[name='DataTables_Table_0_length'] {
        height: 40px !important;
        padding: 10px !important;
        margin-top: 20px;
    }
</style>
