@extends('client.layouts.app-main1')
@section('content')
    @if (session('success'))
        <div class="alert alert-success alert-dismissable fade show text-center">
            <button class="close" data-dismiss="alert" aria-label="Close">×</button>
            {{ session('success') }}
        </div>
    @endif
    <div class="alert alert-success alert-dismissable text-center box_success d-none no-print">
        <button class="close" data-dismiss="alert" aria-label="Close">×</button>
        <span class="msg_success"></span>
    </div>

    <div class="alert alert-dark alert-dismissable text-center box_error d-none no-print">
        <button class="close" data-dismiss="alert" aria-label="Close">×</button>
        <span class="msg_error"></span>
    </div>
    @if (count($errors) > 0)
        <div class="alert alert-dark no-print">
            <button aria-label="Close" class="close" data-dismiss="alert" type="button">
                <span aria-hidden="true">&times;</span>
            </button>
            <strong>الاخطاء :</strong>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form id="myForm" target="_blank" action="#" method="POST">
        @csrf
        @method('POST')
        <h6 class="alert alert-info alert-sm text-center no-print  font-weight-bold" dir="rtl"
            style="background-color: #d8daf5 !important; border:#d8daf5">
            <center>
                {{ __('sidebar.edit-sales-invoice') }} {{ $quotation->quotation_number }}
            </center>
        </h6>

        <div class="row">
            <!----DATE--->
            <div class="col-md-6 pull-right no-print">
                <div class="form-group" dir="rtl">
                    <label>{{ __('sales_bills.invoice-date') }}</label>
                    <span class="text-danger font-weight-bold">*</span>
                    <input type="date" required name="date" id="date" class="form-control"
                        value="{{ $quotation->date ?? date('Y-m-d') }}" />
                    <input type="hidden" id="quotation_id" name="quotation_id" value="{{ $quotation->id }}">

                </div>
            </div>

            <!----TIME--->
            <div class="col-md-6 pull-right no-print">
                <div class="form-group" dir="rtl">
                    <label>{{ __('sales_bills.invoice-time') }}</label>
                    <span class="text-danger font-weight-bold">*</span>
                    <input type="time" required name="time" id="time" class="form-control"
                        value="{{ $quotation->time ?? date('H:i:s') }}" />
                </div>
            </div>
        </div>
        <!----Store--->
        <div class="row">
            <div class="col-md-6 pull-right no-print">
                <label>
                    {{ __('sales_bills.select-store') }}
                    <span class="text-danger font-weight-bold">*</span>
                </label>
                <div class="d-flex justify-content-between">
                    <select name="store_id" id="store_id" class="selectpicker me-2" data-style="btn-new_color"
                        data-live-search="true">
                        <?php $i = 0; ?>
                        @foreach ($stores as $store)
                            <option value="">
                                {{ $store->store_name }}</option>
                            <?php $i++; ?>
                        @endforeach
                    </select>
                    <a target="_blank" href="{{ route('client.stores.create') }}" role="button" class="btn btn-primary ">
                        <i class="fa fa-plus" aria-hidden="true"> </i>
                        {{ __('sales_bills.add-store') }}
                    </a>
                </div>
            </div>
            <!----CLIENT--->
            <div class="col-md-6 pull-right no-print">
                <label>
                    {{ __('sales_bills.client-name') }}
                    <span class="text-danger font-weight-bold">*</span>
                </label>
                <div class="d-flex align-items-center justify-content-between">
                    <select name="outer_client_id" id="outer_client_id" data-style="btn-new_color"
                        title="{{ __('sales_bills.client-name') }}" class="selectpicker w-100 me-2"
                        data-live-search="true">
                        @foreach ($outer_clients as $outer_client)
                            <option {{ $quotation->outer_client_id == $outer_client->id ? 'selected' : '' }}
                                value="{{ $outer_client->id }}">{{ $outer_client->client_name }}</option>
                        @endforeach
                    </select>
                    <a target="_blank" href="{{ route('client.outer_clients.create') }}" role="button"
                        class="btn btn-primary">
                        <i class="fa fa-plus" aria-hidden="true"> </i> {{ __('sales_bills.add-client') }}
                    </a>
                </div>
            </div>
        </div>
        <!--tax-->
        <div class="row mt-2">
            <!----->
            <div class="col-md-6 pull-right no-print">
                <label>
                    {{ __('sales_bills.product-code') }}
                    <span class="text-danger font-weight-bold">*</span>
                </label>
                <div class="d-flex align-items-center justify-content-between">
                    <select name="product_id" id="product_id" class="selectpicker w-50" data-style="btn-new_color"
                        data-live-search="true" title="{{ __('sales_bills.product-code') }}">
                        @foreach ($all_products as $product)
                            <option value="{{ $product->id }}" data-name="{{ strtolower($product->product_name) }}"
                                data-sectorprice="{{ $product->sector_price }}"
                                data-wholesaleprice="{{ $product->wholesale_price }}"
                                data-tokens="{{ $product->code_universal }}"
                                data-remaining="{{ $product->total_remaining }}"
                                data-categorytype="{{ $product->category_type }}" data-unitid="{{ $product->unit_id }}">
                                {{ $product->product_name }}
                            </option>
                        @endforeach
                    </select>
                    {{-- <select name="outer_client_id" id="outer_client_id" data-style="btn-new_color"
                    title="{{ __('sales_bills.client-name') }}" class="selectpicker w-100 me-2" data-live-search="true">
                    @foreach ($outer_clients as $outer_client)
                        <option value="{{ $outer_client->id }}">{{ $outer_client->client_name }}</option>
                    @endforeach
                </select> --}}
                    <a target="_blank" href="{{ route('client.products.create') }}" role="button"
                        class="btn btn-primary">
                        <i class="fa fa-plus" aria-hidden="true"> </i> {{ __('sales_bills.add-product') }}
                    </a>
                </div>
            </div>
            <div class="col-md-6 pull-right no-print">
                <label for="value_added_tax">{{ __('sales_bills.prices-for-tax') }}
                    <span class="text-danger font-weight-bold">*</span>

                </label>

                <div class="d-flex align-items-center justify-content-between">
                    <select disabled required name="value_added_tax" id="value_added_tax" class="selectpicker w-100"
                        data-style="btn-new_color" data-live-search="true">
                        <option {{ $quotation->value_added_tax == '0' ? 'selected' : '' }} value="0">
                            {{ __('sales_bills.not-including-tax') }}</option>
                        <option {{ $quotation->value_added_tax == '2' ? 'selected' : '' }} value="2">
                            {{ __('sales_bills.including-tax') }}</option>
                        <option {{ $quotation->value_added_tax == '1' ? 'selected' : '' }} value="1">
                            {{ __('sales_bills.exempt-tax') }}</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="clearfix no-print"></div>

        <input type="number" id='grand_total_input' name="grand_total" hidden>
        <input type="number" id='grand_tax_input' name="grand_tax" hidden>
        <input type="number" id='grand_discount_input' name="total_discount" hidden>
        <input type="number" value="{{ $quotation->sale_bill_number }}" name="sale_bill_number" hidden>

        <div class="table-responsive">
            <table class="table table-bordered mt-2" id="products_table"
                style="background-color: #ffffff; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); border-radius: 5px;">
                <thead>
                    <tr>
                        <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 10px; font-weight: bold;">
                            {{ __('sales_bills.product') }}</th>
                        <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 10px; font-weight: bold;">
                            {{ __('sales_bills.price_type') }}</th>
                        <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 10px; font-weight: bold;">
                            {{ __('sales_bills.price') }}</th>
                        <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 10px; font-weight: bold;">
                            {{ __('sales_bills.quantity') }}</th>
                        <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 10px; font-weight: bold;">
                            {{ __('sales_bills.unit') }}</th>
                        {{-- <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 5px; font-weight: bold;">
                            {{ __('sales_bills.discount') }}
                            <div class="tax_discount"
                                style="display: inline-block; margin-left: 10px; vertical-align: middle;">
                                <select id="discount_application" class="form-control"
                                    style="font-size: 12px; height: 30px;" name="products_discount_type">
                                    <option value="before_tax">{{ __('sales_bills.discount_before_tax') }}</option>
                                    <option value="after_tax">{{ __('sales_bills.discount_after_tax') }}</option>
                                </select>
                            </div>
                        </th> --}}
                        {{-- <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 10px; font-weight: bold;">
                            {{ __('sales_bills.tax') }}</th> --}}
                        <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 10px; font-weight: bold;">
                            {{ __('sales_bills.total') }}</th>
                        <th
                            style="background-color: #d8daf5; color: #333; text-align: center; padding: 10px; font-weight: bold;">
                            {{ __('sales_bills.actions') }}</th>
                    </tr>
                </thead>
                <tbody style="text-align: center;">
                    <!-- هنا يتم عرض البيانات -->
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="6" style="background-color: #f9f9f9; font-weight: bold;">
                            {{ __('sales_bills.grand_tax') }}</td>
                        <td colspan="3" id="grand_tax" class="text-right" style="background-color: #f9f9f9;">0.00
                        </td>
                    </tr>
                    <tr>
                        <td colspan="6" style="background-color: #f9f9f9; font-weight: bold;">
                            {{ __('sales_bills.grand_total') }}</td>
                        <td colspan="3" id="grand_total" class="text-right" style="background-color: #f9f9f9;">
                            0.00</td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="row">
            <div class="col-md-6 pull-right">
                <div class="form-group" dir="rtl">
                    <label for="discount">{{ __('sales_bills.discount-on-the-total-bill') }}</label> <br>
                    <select name="discount_type" id="discount_type" class="form-control"
                        style="width: 60%;display: inline;float: right; margin-left:5px;">
                        <option value="">اختر نوع الخصم</option>
                        <option {{ $discount?->action_type == 'pound' ? 'selected' : '' }} value="pound">خصم قبل الضريبة
                            (مسطح)</option>
                        <option {{ $discount?->action_type == 'percent' ? 'selected' : '' }} value="percent">خصم قبل
                            الضريبة (%)</option>
                        <option {{ $discount?->action_type == 'poundAfterTax' ? 'selected' : '' }} value="poundAfterTax">
                            ضمان اعمال (مسطح)</option>
                        <option {{ $discount?->action_type == 'poundAfterTaxPercent' ? 'selected' : '' }}
                            value="poundAfterTaxPercent">ضمان اعمال (%)</option>
                        <option {{ $discount?->action_type == 'afterTax' ? 'selected' : '' }} value="afterTax"
                            class="d-none">
                            خصم علي اجمالي المبلغ شامل الضريبة
                        </option>
                    </select>
                    <input type="number" name="discount_value" min="0"
                        style="width: 20%;display: inline;float: right;" id="discount_value" class="form-control "
                        value="{{ $discount?->value }}" step = "any" />
                    <input type="text" name="discount_note" value="{{ $discount?->discount_note }}"
                        id="discount_note" placeholder="ملاحظات الخصم. . ." class="form-control mt-5"
                        style="width: 80%;">
                    {{-- <span id="dicountForBill"></span> --}}
                </div>


            </div>
            <div class="col-md-6 pull-right">
                <div class="form-group" dir="rtl">
                    <label for="extra">{{ __('main.shipping-expenses') }}</label> <br>

                    <select name="extra_type" id="extra_type" class="form-control"
                        style="width:60%;display: inline;float: right;margin-left: 5px">
                        <option value="">اختر نوع الشحن</option>
                        <option {{ $shipping?->action_type == 'pound' ? 'selected' : '' }} value="pound">
                            {{ $extra_settings->currency }}</option>
                        <option {{ $shipping?->action_type == 'percent' ? 'selected' : '' }} value="percent">%</option>
                    </select>
                    <input type="number" name="extra_value" min='0'
                        style="width: 20%;display: inline;float: right;" id="extra_value" class="form-control"
                        value="{{ $shipping?->value }}" step = "any" />
                </div>
            </div>
        </div><!--  End Row -->
        <!-----notes------->
        <div class="col-sm-12 pull-right no-print">
            <div class="form-group" dir="rtl">
                <label for="time">{{ __('main.notes') }}</label>
                <textarea name="notes" id="notes" class="summernotes">
                {{ $quotation->notes }}
                  </textarea>
                <a data-toggle="modal" data-target="#myModal3" class="btn btn-link add_extra_notes d-none"
                    style="color: blue!important;">
                    اضف ملاحظات اخرى
                </a>
            </div>
        </div>
        <div class="clearfix no-print"></div>

        <hr>
        </div>
        <div class="company_details printy" style="display: none;">
            <div class="text-center">
                <img class="logo" style="width: 20%;" src="{{ asset($company->company_logo) }}" alt="">
            </div>
            <div class="text-center">
                <div class="col-lg-12 text-center justify-content-center">
                    <p class="alert alert-info text-center alert-sm"
                        style="margin: 10px auto; font-size: 17px;line-height: 1.9;" dir="rtl">
                        {{ $company->company_name }} -- {{ $company->business_field }} <br>
                        {{ $company->company_owner }} -- {{ $company->phone_number }} <br>
                    </p>
                </div>
            </div>
        </div>

        <div class="col-lg-12 no-print text-center"
            style="padding-top: 25px;height: auto !important;display: flex;justify-content: center;">


            <button type="button" id="add" class="btn btn-info btn-md ml-1" style="height: 40px;">
                {{-- <i class="fa fa-plus"></i> --}}
                {{ __('sales_bills.update') }}
            </button>

        </div>

    </form>


    <input type="hidden" id="final_total" />
    <input type="hidden" id="product" placeholder="product" name="product" />
    <input type="hidden" id="net_total" placeholder="اجمالى قبل الخصم" name="total" />
    <input type="hidden" value="0" id="check" />
    <style>
        input {
            min-width: 100px;
        }

        select {
            min-width: 100px;
        }
    </style>
    <script src="{{ asset('app-assets/js/jquery.min.js') }}"></script>
    <script>
        var translations = {
            sector: "{{ __('sales_bills.sector') }}",
            wholesale: "{{ __('sales_bills.wholesale') }}",
            choose_unit: "{{ __('sales_bills.choose_unit') }}",
            pound: "{{ __('sales_bills.pound') }}",
            percent: "{{ __('sales_bills.percent') }}",
            include_tax: "{{ __('sales_bills.include_tax') }}",
            remove: "{{ __('sales_bills.remove') }}",
            max_quantity: "{{ __('sales_bills.max_quantity') }}",
            not_including_tax: "{{ __('sales_bills.not-including-tax') }}",
            including_tax: "{{ __('sales_bills.including-tax') }}",
            exempt_tax: "{{ __('sales_bills.exempt-tax') }}",
        };
    </script>
    <script>
        // Initialize rowIndex with the current count of existing rows
        var rowIndex = {{ count($quotation->elements) }};

        // Function to populate existing elements into the table
        @foreach ($quotation->elements as $index => $element)
            var rowHtml = `
                <tr data-product-id="{{ $element->product_id }}" data-index="{{ $index }}">
                    <td>{{ $element->product->product_name }}</td>
                    <td class="text-left">
                        <label>
                            <input type="radio" name="products[{{ $index }}][price_type]" required value="sector" class="price_type" {{ $element->price_type == 'sector' ? 'checked' : '' }}>
                            ${translations.sector}
                        </label>
                        <label>
                            <input type="radio" name="products[{{ $index }}][price_type]" required value="wholesale" class="price_type" {{ $element->price_type == 'wholesale' ? 'checked' : '' }}>
                            ${translations.wholesale}
                        </label>
                    </td>
                    <td>
                        <input type="number" min="1" name="products[{{ $index }}][product_price]" class="form-control price" value="{{ $element->product_price }}" step="any">
                    </td>
                    <td>
                        <input type="number" name="products[{{ $index }}][quantity]" class="form-control quantity" value="{{ $element->quantity }}" min="1" max="{{ $element->remaining }}" step="any">
                    </td>
                    <td>
                        <select name="products[{{ $index }}][unit_id]" class="form-control unit">
                            <option disabled>${translations.choose_unit}</option>
                            @foreach ($units as $unit)
                                <option value="{{ $unit->id }}" {{ $element->unit_id == $unit->id ? 'selected' : '' }}>{{ $unit->unit_name }}</option>
                            @endforeach
                        </select>
                    </td>
                    <td class="hidden">
                        <label>
                            <input type="radio" name="products[{{ $index }}][discount_type]" value="pound" class="discount_type" {{ $element->discount_type == 'pound' ? 'checked' : '' }}>
                            ${translations.pound}
                        </label>
                        <label>
                            <input type="radio" name="products[{{ $index }}][discount_type]" value="percent" class="discount_type" {{ $element->discount_type == 'percent' ? 'checked' : '' }}>
                            ${translations.percent}
                        </label>
                        <input
                            type="number"
                            name="products[{{ $index }}][discount]"
                            class="form-control discount"
                            value="{{ $element->discount_value }}"
                            min="0"
                            step="any">
                    </td>
                    <td class="hidden">
                        <select name="products[{{ $index }}][tax]" class="form-control tax_type w-100 mb-1">
                            <option value="0" {{ $element->tax_type == 0 ? 'selected' : '' }}>${translations.not_including_tax}</option>
                            <option value="1" {{ $element->tax_type == 1 ? 'selected' : '' }}>${translations.exempt_tax}</option>
                            <option value="2" {{ $element->tax_type == 2 ? 'selected' : '' }}>${translations.including_tax}</option>
                        </select>
                        <input type="number" name="products[{{ $index }}][tax_amount]" class="form-control tax_amount" value="{{ $element->tax_value }}" readonly step="any">
                    </td>
                    <td>
                        <input type="number" name="products[{{ $index }}][total]" class="form-control total" value="{{ $element->quantity_price }}" readonly step="any">
                        <input type="number" hidden name="products[{{ $index }}][product_id]" class="form-control" value="{{ $element->product_id }}">
                    </td>
                    <td>
                        <button type="button" class="btn btn-danger remove-product">${translations.remove}</button>
                    </td>
                </tr>
                `;

            $('#products_table tbody').append(rowHtml);
        @endforeach
    </script>

    <script>
        var somethingChanged = false;
        $(document).ready(function() {
            $('.summernotes').summernote({
                height: 100,
                direction: 'rtl',
            });
        })
        //onsave btn حفظ الفاتورة
        $(document).ready(function() {
            $('#value_added_tax').on('change', function() {
                const newTaxType = $(this).val();

                // Show a SweetAlert confirmation dialog
                Swal.fire({
                    title: 'تأكيد التغيير',
                    text: 'سيتم تغيير نوع الضريبة لجميع العناصر في الجدول إلى القيمة المحددة. هل تريد المتابعة؟',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'نعم، تغيير',
                    cancelButtonText: 'إلغاء',
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Update all tax types in the table to match the selected value
                        $('#products_table tbody tr').each(function() {
                            $(this).find('select[name*="[tax]"]').val(newTaxType).trigger(
                                'change');
                        });

                        handleTaxCalculation(); // Recalculate taxes after the update
                        Swal.fire(
                            'تم التغيير!',
                            'تم تحديث نوع الضريبة بنجاح.',
                            'success'
                        );
                    } else {
                        // Reset the dropdown to its previous value
                        $(this).val($(this).data('previous-value'));
                    }
                });

                // Save the current value as previous for potential reset
                $(this).data('previous-value', newTaxType);
            });
            $('.save_btn1').on('click', function() {
                let outerClientId = $('#outer_client_id').val();

                // Check if the outer client ID is selected
                if (!outerClientId) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'تحذير',
                        text: 'يجب اختيار العميل',
                        confirmButtonText: 'موافق'
                    });
                    return false;
                }

                // Validate that at least one product is selected
                let hasProduct = false;
                $('#products_table tbody tr').each(function() {
                    let quantity = $(this).find('input[name*="[quantity]"]').val();
                    let price = $(this).find('input[name*="[product_price]"]').val();

                    let unit = $(this).find('select[name*="[unit_id]"]').val();

                    if (quantity > 0 && price > 0 && unit) {
                        hasProduct = true;
                    }
                });

                if (!hasProduct) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'تحذير',
                        text: 'يجب اختيار منتج واحد على الأقل، وتحديد الكمية، والسعر، والوحدة لكل منتج',
                        confirmButtonText: 'موافق'
                    });
                    return false;
                }
                var formData = $('#myForm').serialize();

                $.post("{{ url('/client/sale-bills/saveAll') }}", formData, function(data) {

                    location.href = '/sale-bills/print/' + data;
                });
            });

            //onsave btn حفظ الفاتورة
            $('.save_btn2').on('click', function() {
                let printColor = $(this).attr('printColor');
                let isMoswada = $(this).attr('isMoswada');
                let invoiceType = $(this).attr('invoiceType');
                let outerClientId = $('#outer_client_id').val();

                // Check if the outer client ID is selected
                if (!outerClientId) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'تحذير',
                        text: 'يجب اختيار العميل',
                        confirmButtonText: 'موافق'
                    });
                    return false;
                }

                // Validate that at least one product is selected
                let hasProduct = false;
                $('#products_table tbody tr').each(function() {
                    let quantity = $(this).find('input[name*="[quantity]"]').val();
                    let price = $(this).find('input[name*="[product_price]"]').val();
                    let unit = $(this).find('select[name*="[unit_id]"]').val();

                    if (quantity > 0 && price > 0 && unit) {
                        hasProduct = true;
                    }
                });

                if (!hasProduct) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'تحذير',
                        text: 'يجب اختيار منتج واحد على الأقل، وتحديد الكمية، والسعر، والوحدة لكل منتج',
                        confirmButtonText: 'موافق'
                    });
                    return false;
                }
                var formData = $('#myForm').serialize();

                $.post("{{ url('/client/sale-bills/saveAll') }}", formData, function(data) {
                    location.href = '/sale-bills/print/' + data + '/' + invoiceType + '/' +
                        printColor + '/' +
                        isMoswada;
                });
            });

            $('#outer_client_id').on('change', function() {
                let outer_client_id = $(this).val();
                if (outer_client_id != "") {
                    $('.outer_client_details').fadeIn(200);
                    $.post("{{ url('/client/sale-bills/getOuterClientDetails') }}", {
                        outer_client_id: outer_client_id,
                        "_token": "{{ csrf_token() }}"
                    }, function(data) {
                        $('#category').html(data.category);
                        $('#balance_before').html(data.balance_before);
                        $('#client_national').html(data.client_national);
                        $('#tax_number').html(data.tax_number);
                        $('#shop_name').html(data.shop_name);
                        $('#client_phone').html(data.client_phone);
                        $('#client_address').html(data.client_address);
                    });
                } else {
                    $('.outer_client_details').fadeOut(200);
                }
            });
            $('#store_id').on('change', function() {
                let store_id = $(this).val();
                if (store_id != "" || store_id != "0") {
                    $('.options').fadeIn(200);
                    $.post("{{ url('/client/sale-bills/getProducts') }}", {
                        store_id: store_id,
                        "_token": "{{ csrf_token() }}"
                    }, function(data) {
                        $('select#product_id').html(data);
                        $('select#product_id').selectpicker('refresh');
                    });
                } else {
                    $('.options').fadeOut(200);
                }
            });
            $('#product_id').on('change', function() {
                $('#sector').prop('checked', false);
                $('#quantity').val('');
                $('#quantity_price').val('');
                let sale_bill_number = $('#sale_bill_number').val();
                let product_id = $(this).val();
                $.post("{{ url('/client/sale-bills/get') }}", {
                    product_id: product_id,
                    sale_bill_number: sale_bill_number,
                    "_token": "{{ csrf_token() }}"
                }, function(data) {
                    $('#wholesale').prop('checked', true);
                    $('input#product_price').val(data.wholesale_price);
                    $('input#quantity_price').val(data.wholesale_price);
                    $('input#quantity').val("1");
                    $('select#unit_id').val(data.unit_id);
                    $('input#quantity').attr('max', data.first_balance);
                    $('.available').html('الكمية المتاحة : ' + data.first_balance);
                });
            });
            $('#wholesale').on('click', function() {
                let product_id = $('#product_id').val();
                $.post("{{ url('/client/sale-bills/get') }}", {
                    product_id: product_id,
                    "_token": "{{ csrf_token() }}"
                }, function(data) {
                    $('input#product_price').val(data.wholesale_price);
                    let quantity = $('#quantity').val();
                    let quantity_price = quantity * data.wholesale_price;
                    $('#quantity_price').val(quantity_price);
                });
            });
            $('#sector').on('click', function() {
                let product_id = $('#product_id').val();
                $.post("{{ url('/client/sale-bills/get') }}", {
                    product_id: product_id,
                    "_token": "{{ csrf_token() }}"
                }, function(data) {
                    $('input#product_price').val(data.sector_price);
                    let quantity = $('#quantity').val();
                    let quantity_price = quantity * data.sector_price;
                    $('#quantity_price').val(quantity_price);
                });
            });
            $('#quantity').on('keyup change', function() {
                let product_id = $('#product_id').val();
                let product_price = $('#product_price').val();
                let quantity = $(this).val();
                let quantity_price = quantity * product_price;
                $('#quantity_price').val(quantity_price);
            });
            $('#product_price').on('keyup change', function() {
                let product_id = $('#product_id').val();
                let product_price = $(this).val();
                let quantity = $('#quantity').val();
                let quantity_price = quantity * product_price;
                $('#quantity_price').val(quantity_price);
            });

        });

        //add-new-sale-bill button --- اضافة فاتورة بيع جديدة.
        $(document).ready(function() {

            $('#add').on('click', function() {
                let outerClientId = $('#outer_client_id').val();

                // Check if the outer client ID is selected
                if (!outerClientId) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'تحذير',
                        text: 'يجب اختيار العميل',
                        confirmButtonText: 'موافق'
                    });
                    return false;
                }

                // Validate that at least one product is selected
                let hasProduct = false;
                $('#products_table tbody tr').each(function() {
                    let quantity = $(this).find('input[name*="[quantity]"]').val();
                    let price = $(this).find('input[name*="[product_price]"]').val();
                    let unit = $(this).find('select[name*="[unit_id]"]').val();

                    if (quantity > 0 && price > 0 && unit) {
                        hasProduct = true;
                    }
                });

                if (!hasProduct) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'تحذير',
                        text: 'يجب اختيار منتج واحد على الأقل، وتحديد الكمية، والسعر، والوحدة لكل منتج',
                        confirmButtonText: 'موافق'
                    });
                    return false;
                }

                // var formData = $('#myForm').serialize();
                // $.post("{{ url('/client/quotation/update') }}", formData, function(data) {

                //     if (data.status === true) {
                //         // Show success message
                //         $('.box_success').removeClass('d-none').fadeIn(200);
                //         $('.msg_success').html(data.msg);
                //         $('.box_success').delay(3000).fadeOut(300);
                //         window.location.href = `/client/quotations/view/${data.id}`;
                //     } else {
                //         // Show error message using SweetAlert
                //         let errorMessage = data.message;
                //         let errorDetails = '';

                //         // If there are errors in the 'errors' object, build the message
                //         if (data.errors) {
                //             $.each(data.errors, function(field, messages) {
                //                 errorDetails += messages.join('<br>') + '<br>';
                //             });
                //         }

                //         // Use SweetAlert to display the error message
                //         Swal.fire({
                //             icon: 'error',
                //             title: 'خطأ',
                //             html: errorMessage + '<br>' +
                //                 errorDetails, // Combine the general message with the field-specific errors
                //             confirmButtonText: 'موافق'
                //         });
                //     }
                // });
                var id = $('#quotation_id').val(); // Make sure this input exists and holds the correct ID
                var formData = $('#myForm').serialize();

                $.post(`/client/quotation/update/${id}`, formData, function(data) {
                    if (data.status === true) {
                        $('.box_success').removeClass('d-none').fadeIn(200);
                        $('.msg_success').html(data.msg);
                        $('.box_success').delay(3000).fadeOut(300);

                        window.location.href = `/client/quotations/view/${data.quotation_number}`;
                    } else {
                        let errorMessage = data.message;
                        let errorDetails = '';

                        if (data.errors) {
                            $.each(data.errors, function(field, messages) {
                                errorDetails += messages.join('<br>') + '<br>';
                            });
                        }

                        Swal.fire({
                            icon: 'error',
                            title: 'خطأ',
                            html: errorMessage + '<br>' + errorDetails,
                            confirmButtonText: 'موافق'
                        });
                    }
                });


            });


        });




        // apply discount //
        $('#exec_discount').on('click', function() {
            let sale_bill_number = $('#sale_bill_number').val();
            let discount_type = $('#discount_type').val();
            let discount_value = $('#discount_value').val();
            let discount_note = $('#discount_note').val();

            // apply discount //
            $.post("{{ url('/client/sale-bills/discount') }}", {
                "_token": "{{ csrf_token() }}",
                sale_bill_number: sale_bill_number,
                discount_type: discount_type,
                discount_value: discount_value,
                discount_note: discount_note
            }, function(data) {
                alert('تم تطبيق الخصم');
                $('.after_totals').html(data);
            });

            // refresh //
            $.post("{{ url('/client/sale-bills/refresh') }}", {
                "_token": "{{ csrf_token() }}",
                sale_bill_number: sale_bill_number,
            }, function(data) {
                $('#final_total').val(data.final_total);
            });
        });

        $('.pay_btn').on('click', function() {
            let final_total = $('#grand_total_input').val();
            $('#amount').val(final_total);
        })

        $('.edit_element').on('click', function() {
            let element_id = $(this).attr('element_id');
            let sale_bill_number = $(this).attr('sale_bill_number');

            $.post("{{ url('/client/sale-bills/edit-element') }}", {
                "_token": "{{ csrf_token() }}",
                sale_bill_number: sale_bill_number,
                element_id: element_id
            }, function(data) {
                $('#product_id').val(data.product_id);
                $('#product_id').selectpicker('refresh');
                $('#product_price').val(data.product_price);
                $('#unit_id').val(data.unit_id);
                $('#quantity').val(data.quantity);
                $('#quantity_price').val(data.quantity_price);
                let product_id = data.product_id;
                $.post("{{ url('/client/sale-bills/get-edit') }}", {
                    product_id: product_id,
                    sale_bill_number: sale_bill_number,
                    "_token": "{{ csrf_token() }}"
                }, function(data) {
                    $('input#quantity').attr('max', data.first_balance);
                    $('.available').html('الكمية المتاحة : ' + data.first_balance);
                });
                $('#add').hide();
                $('#edit').show();
                $('#edit').attr('element_id', element_id);
                $('#edit').attr('sale_bill_number', sale_bill_number);

            });
        });

        $('#edit').on('click', function() {
            let element_id = $(this).attr('element_id');
            let sale_bill_number = $(this).attr('sale_bill_number');

            let product_id = $('#product_id').val();
            let product_price = $('#product_price').val();
            let quantity = $('#quantity').val();
            let quantity_price = $('#quantity_price').val();
            let unit_id = $('#unit_id').val();

            let discount_type = $('#discount_type').val();
            let discount_value = $('#discount_value').val();
            let first_balance = parseFloat($('#quantity').attr('max'));
            let extra_type = $('#extra_type').val();
            let extra_value = $('#extra_value').val();
            let value_added_tax = $('#value_added_tax').val();
            if (!isNaN(first_balance)) {
                if (product_id == "" || product_id <= "0") {
                    alert("لابد ان تختار المنتج أولا");
                } else if (product_price == "" || product_price == "0") {
                    alert("لم يتم اختيار سعر المنتج");
                } else if (quantity == "" || quantity <= "0" || quantity > first_balance) {
                    alert("الكمية غير مناسبة");
                } else if (quantity_price == "" || quantity_price == "0") {
                    alert("الكمية غير مناسبة او الاجمالى غير صحيح");
                } else if (unit_id == "" || unit_id == "0") {
                    alert("اختر الوحدة");
                } else {
                    $.post('/client/sale-bills/element/update', {
                        '_token': "{{ csrf_token() }}",
                        element_id: element_id,
                        value_added_tax: value_added_tax,
                        product_id: product_id,
                        product_price: product_price,
                        quantity: quantity,
                        quantity_price: quantity_price,
                        unit_id: unit_id,
                    }, function(data) {
                        $.post('/client/sale-bills/elements', {
                            '_token': "{{ csrf_token() }}",
                            sale_bill_number: sale_bill_number
                        }, function(elements) {
                            $('.bill_details').html(elements);
                        });

                        $('#add').show();
                        $('#edit').hide();
                        $('#product_id').val('').trigger('change');
                        $('#unit_id').val('');
                        $('.available').html("");
                        $('#product_price').val('0');
                        $('#quantity').val('');
                        $('#quantity_price').val('');
                    });
                    $.post('/client/sale-bills/discount', {
                        '_token': "{{ csrf_token() }}",
                        sale_bill_number: sale_bill_number,
                        discount_type: discount_type,
                        discount_value: discount_value
                    }, function(data) {
                        alert('تم تطبيق الخصم');
                        $('.after_totals').html(data);
                    });

                    $.post('/client/sale-bills/extra', {
                        '_token': "{{ csrf_token() }}",
                        sale_bill_number: sale_bill_number,
                        extra_type: extra_type,
                        extra_value: extra_value
                    }, function(data) {
                        $('.after_totals').html(data);
                    });
                    $.post("{{ url('/client/sale-bills/refresh') }}", {
                        "_token": "{{ csrf_token() }}",
                        sale_bill_number: sale_bill_number,
                    }, function(data) {
                        $('#final_total').val(data.final_total);
                    });
                }
            } else {

                $.post('/client/sale-bills/element/update', {
                    '_token': "{{ csrf_token() }}",
                    element_id: element_id,
                    product_id: product_id,
                    value_added_tax: value_added_tax,
                    product_price: product_price,
                    quantity: quantity,
                    quantity_price: quantity_price,
                    unit_id: unit_id,
                }, function(data) {
                    $.post('/client/sale-bills/elements', {
                        '_token': "{{ csrf_token() }}",
                        sale_bill_number: sale_bill_number
                    }, function(elements) {
                        $('.bill_details').html(elements);
                    });
                    $('#add').show();
                    $('#edit').hide();
                    $('#product_id').val('').trigger('change');
                    $('#unit_id').val('');
                    $('.available').html("");
                    $('#product_price').val('0');
                    $('#quantity').val('');
                    $('#quantity_price').val('');
                });

                $.post('/client/sale-bills/discount', {
                    '_token': "{{ csrf_token() }}",
                    sale_bill_number: sale_bill_number,
                    discount_type: discount_type,
                    discount_value: discount_value
                }, function(data) {
                    alert('تم تطبيق الخصم');
                    $('.after_totals').html(data);
                });

                $.post('/client/sale-bills/extra', {
                    '_token': "{{ csrf_token() }}",
                    sale_bill_number: sale_bill_number,
                    extra_type: extra_type,
                    extra_value: extra_value
                }, function(data) {
                    $('.after_totals').html(data);
                });

                $.post("{{ url('/client/sale-bills/refresh') }}", {
                    "_token": "{{ csrf_token() }}",
                    sale_bill_number: sale_bill_number,
                }, function(data) {
                    $('#final_total').val(data.final_total);
                });
            }

        });

        $('.remove_element').on('click', function() {
            let element_id = $(this).attr('element_id');
            let sale_bill_number = $(this).attr('sale_bill_number');

            let discount_type = $('#discount_type').val();
            let discount_value = $('#discount_value').val();

            let extra_type = $('#extra_type').val();
            let extra_value = $('#extra_value').val();

            $.post('/client/sale-bills/element/delete', {
                '_token': "{{ csrf_token() }}",
                element_id: element_id
            }, function(data) {
                $.post('/client/sale-bills/elements', {
                    '_token': "{{ csrf_token() }}",
                    sale_bill_number: sale_bill_number
                }, function(elements) {
                    $('.bill_details').html(elements);
                });
            });

            $.post('/client/sale-bills/discount', {
                '_token': "{{ csrf_token() }}",
                sale_bill_number: sale_bill_number,
                discount_type: discount_type,
                discount_value: discount_value
            }, function(data) {
                $('.after_totals').html(data);
            });

            $.post('/client/sale-bills/extra', {
                '_token': "{{ csrf_token() }}",
                sale_bill_number: sale_bill_number,
                extra_type: extra_type,
                extra_value: extra_value
            }, function(data) {
                $('.after_totals').html(data);
            });

            $.post("{{ url('/client/sale-bills/refresh') }}", {
                "_token": "{{ csrf_token() }}",
                sale_bill_number: sale_bill_number,
            }, function(data) {
                $('#final_total').val(data.final_total);
            });

            $(this).parent().parent().fadeOut(300);
        });

        $('#exec_extra').on('click', function() {
            let sale_bill_number = $('#sale_bill_number').val();
            let extra_type = $('#extra_type').val();
            let extra_value = $('#extra_value').val();
            $.post("{{ url('/client/sale-bills/extra') }}", {
                "_token": "{{ csrf_token() }}",
                sale_bill_number: sale_bill_number,
                extra_type: extra_type,
                extra_value: extra_value
            }, function(data) {
                $('.after_totals').html(data);
            });

            $.post("{{ url('/client/sale-bills/refresh') }}", {
                "_token": "{{ csrf_token() }}",
                sale_bill_number: sale_bill_number,
            }, function(data) {
                $('#final_total').val(data.final_total);
            });
        });

        $('#payment_method').on('change', function() {
            let payment_method = $(this).val();
            if (payment_method == "cash") {
                $('.cash').show();
                $('.bank').hide();
            } else if (payment_method == "bank") {
                $('.bank').show();
                $('.cash').hide();
            } else {
                $('.bank').hide();
                $('.cash').hide();
            }
        });

        function checkChanges() {
            somethingChanged = true
        }


        window.addEventListener("pageshow", function(event) {
            var historyTraversal = event.persisted ||
                (typeof window.performance != "undefined" &&
                    window.performance.navigation.type === 2);
            if (historyTraversal) {
                // Handle page restore.
                window.location.reload();
            }
        });

        $(document).ready(function() {
            var rowIndex = 0;
            var roductPrice = 0;

            function handleTaxCalculation(flag = 1) {
                var taxRate = 0.15; // Tax rate of 15%

                $('#products_table tbody tr').each(function() {
                    var row = $(this);
                    var taxTypeSelect = row.find(`select[name="products[${row.data('index')}][tax]"]`);
                    var taxAmountField = row.find(
                        `input[name="products[${row.data('index')}][tax_amount]"]`);
                    var productPrice = parseFloat(row.find(
                        `input[name="products[${row.data('index')}][product_price]"]`).val()) || 0;
                    var quantity = parseFloat(row.find(
                        `input[name="products[${row.data('index')}][quantity]"]`).val()) || 0;
                    var taxType = taxTypeSelect.val();
                    var tax = 0;

                    switch (taxType) {
                        case "2": // Including tax
                            tax = (productPrice - (productPrice / (1 + taxRate))) *
                                quantity; // Calculate the tax amount considering quantity
                            taxAmountField.show().val(tax.toFixed(2));
                            break;
                        case "0": // Not including tax
                            tax = (productPrice * taxRate) *
                                quantity; // Calculate the tax amount considering quantity
                            taxAmountField.show().val(tax.toFixed(2));
                            break;
                        case "1": // Exempt from tax
                        default:
                            taxAmountField.show().val(0); // Set tax to 0 if exempt
                            break;
                    }

                    calculateRowTotal(row); // Recalculate the row total after updating the tax
                });

                calculateGrandTotal(); // Recalculate the grand total after updating all rows
            }

            function calculateRowTotal(row) {
                var taxType = row.find(`select[name="products[${row.data('index')}][tax]"]`)
                    .val(); // Get tax type for this row

                var quantity = parseFloat(row.find(`input[name="products[${row.data('index')}][quantity]"]`)
                    .val()) || 0;
                var price = parseFloat(row.find(`input[name="products[${row.data('index')}][product_price]"]`)
                    .val()) || 0;
                var discount = parseFloat(row.find(`input[name="products[${row.data('index')}][discount]"]`)
                    .val()) || 0;
                var discountType = row.find(`input[name="products[${row.data('index')}][discount_type]"]:checked`)
                    .val();
                var taxRate = 0.15; // 15% tax rate
                var discountApplication = $('#discount_application')
                    .val(); // whether discount is applied before or after tax

                var subtotal = quantity * price;
                var discountAmount = discountType === 'percent' ? (subtotal * discount / 100) : discount;

                var total;
                var taxValue = 0; // Default to no tax

                // If discount is applied before tax
                if (discountApplication === 'before_tax') {
                    // Subtotal after applying discount
                    var discountedSubtotal = subtotal - discountAmount;

                    // Apply tax based on tax type
                    if (taxType === "0") { // Not including tax
                        taxValue = discountedSubtotal * taxRate;
                    } else if (taxType === "2") { // Including tax
                        // No additional tax, already included in price
                        taxValue = 0;
                    } else if (taxType === "1") { // Exempt from tax
                        taxValue = 0;
                    }

                    total = discountedSubtotal + taxValue;

                } else { // If discount is applied after tax
                    // Apply tax based on the subtotal before discount
                    if (taxType === "0") { // Not including tax
                        taxValue = subtotal * taxRate;
                    } else if (taxType === "2") { // Including tax
                        // No additional tax, already included in price
                        taxValue = 0;
                    } else if (taxType === "1") { // Exempt from tax
                        taxValue = 0;
                    }

                    // Total after applying tax and then subtracting the discount
                    total = subtotal + taxValue - discountAmount;
                }

                // Update row fields
                row.find(`input[name="products[${row.data('index')}][applied_discount]"]`).val(discountAmount
                    .toFixed(2));
                row.find(`input[name="products[${row.data('index')}][tax_amount]"]`).val(taxValue.toFixed(2));
                row.find(`input[name="products[${row.data('index')}][total]"]`).val(total.toFixed(2));

                calculateGrandTotal(); // Update the overall totals
            }

            function calculateGrandTotal() {
                var grandTotal = 0;
                var grandTotalWithoutChange = 0;
                var totalAppliedDiscount = 0;
                var totalDiscount = 0;
                var discount = 0;
                var grandTax = 0;
                var discountType = $('#discount_type').val();
                var discountValue = parseFloat($('#discount_value').val()) || 0;
                var extraType = $('#extra_type').val();
                var extraValue = parseFloat($('#extra_value').val()) || 0;

                $('#products_table tbody tr').each(function() {
                    var total = parseFloat($(this).find(
                        `input[name="products[${$(this).data('index')}][total]"]`).val()) || 0;
                    var appliedDiscount = parseFloat($(this).find(
                            `input[name="products[${$(this).data('index')}][applied_discount]"]`).val()) ||
                        0;
                    var totalWithoutChange = parseFloat($(this).find(
                        `input[name="products[${$(this).data('index')}][product_price]"]`).val()) || 0;

                    var taxAmount = parseFloat($(this).find(
                        `input[name="products[${$(this).data('index')}][tax_amount]"]`).val()) || 0;
                    grandTotal += total;
                    grandTotalWithoutChange += totalWithoutChange;
                    totalAppliedDiscount += appliedDiscount;
                    grandTax += taxAmount;
                });

                // Apply discount to grand total based on the selected option
                // var discount = 0;
                // Apply discount based on type
                // var oldgrandToatal = grandTotal;
                // var oldgrandTax = grandTax;
                var valueAddedTax = $('#value_added_tax').val(); // الحصول على إعداد الضريبة المختار

                var totalWithoutTax = grandTotal - grandTax;
                var taxRatio = valueAddedTax == 0 ? .15 : 0;
                if (discountType === 'pound') {
                    total = totalWithoutTax - discountValue;
                    // grandTax = total * taxRatio;
                    grandTotal = total + grandTax;
                } else if (discountType === 'percent') {
                    discountValue = (totalWithoutTax * discountValue / 100);
                    total = totalWithoutTax - discountValue;
                    // grandTax = total * taxRatio;
                    grandTotal = total + grandTax;
                }

                // Apply discounts after tax if specified
                if (discountType === 'poundAfterTax') {
                    grandTotal -= discountValue; // Apply flat discount after tax

                } else if (discountType === 'poundAfterTaxPercent') {
                    discountValue = (grandTotal * discountValue / 100);
                    grandTotal -= discountValue; // Apply percentage discount after tax
                }

                // Apply extra charges
                if (extraType === 'percent') {
                    grandTotal += (grandTotal * extraValue / 100); // Extra as percentage
                } else if (extraType === 'pound') {
                    grandTotal += extraValue; // Extra as fixed amount
                }

                // Total discount = row-level discounts + bill-level discounts
                totalDiscount = totalAppliedDiscount + discountValue;
                $('#grand_tax').text(grandTax.toFixed(2));
                $('#grand_total').text(grandTotal.toFixed(2));
                $('#grand_tax_input').val(grandTax.toFixed(2));
                $('#grand_total_input').val(grandTotal.toFixed(2));
                $('#grand_discount_input').val(totalDiscount.toFixed(2));
                $('#dicountForBill').text(discount);

            }

            function reindexRows() {
                $('#products_table tbody tr').each(function(index) {
                    $(this).data('index', index);
                    $(this).find('input, select').each(function() {
                        var name = $(this).attr('name');
                        if (name) {
                            var newName = name.replace(/\[\d+\]/, `[${index}]`);
                            $(this).attr('name', newName);
                        }
                    });
                });
                rowIndex = $('#products_table tbody tr').length;
            }

            $('#value_added_tax').on('change', function() {
                handleTaxCalculation();
            });

            $('#product_id').on('change', function() {
                let rowIndex = $('#products_table tbody tr').length;
                var productId = $(this).val();
                var productName = $('option:selected', this).data('name');
                var sectorPrice = $('option:selected', this).data('sectorprice');
                var wholesalePrice = $('option:selected', this).data('wholesaleprice');
                var categoryType = $('option:selected', this).data('categorytype');
                var unitId = $('option:selected', this).data('unitid') || 191; // Default to 191 if null
                var existingRow = $(`#products_table tbody tr[data-product-id="${productId}"]`);
                var remaining = categoryType !== "خدمية" ? $('option:selected', this).data('remaining') :
                    99999;
                var valueAddedTax = $('#value_added_tax').val(); // الحصول على إعداد الضريبة المختار
                console.log(valueAddedTax);
                $(this).val("");
                if (existingRow.length > 0) {
                    var quantityInput = existingRow.find(
                        `input[name="products[${existingRow.data('index')}][quantity]"]`);
                    var currentQuantity = parseFloat(quantityInput.val()) || 0;
                    var newQuantity = currentQuantity + 1;

                    // if (categoryType !== "خدمية" && newQuantity > remaining) {
                    //     alert(`${translations.max_quantity} ${remaining}`);
                    //     newQuantity = remaining;
                    // }

                    quantityInput.val(newQuantity);
                    calculateRowTotal(existingRow);
                } else {
                    var rowHtml = `
                  <tr data-product-id="${productId}" data-index="${rowIndex}">
                      <td>${productName}</td>
                      <td class="text-left">
                          <label>
                              <input type="radio" name="products[${rowIndex}][price_type]" value="sector" class="price_type" checked>
                              ${translations.sector}
                          </label>
                          <label>
                              <input type="radio" name="products[${rowIndex}][price_type]" value="wholesale" class="price_type">
                              ${translations.wholesale}
                          </label>
                      </td>
                      <td>
                          <input type="number" min="1" name="products[${rowIndex}][product_price]" class="form-control form-control-sm price w-auto" value="${sectorPrice}" step="any">
                      </td>
                      <td>
                          <input type="number" name="products[${rowIndex}][quantity]" class="form-control form-control-sm quantity w-auto" value="1" min="1" max="${remaining}" step="any">
                      </td>
                      <td>
                          <select name="products[${rowIndex}][unit_id]" class="form-control form-control-sm unit w-auto">
                              <option disabled>${translations.choose_unit}</option>
                              @foreach ($units as $unit)
                                  <option value="{{ $unit->id }}" ${unitId === {{ $unit->id }} ? 'selected' : ''}>{{ $unit->unit_name }}</option>
                              @endforeach
                          </select>
                          <select name="products[${rowIndex}][tax]" hidden class="form-control tax_type w-auto mb-1">
                              <option value="0" ${valueAddedTax == 0 ? 'selected' : ''}>${translations.not_including_tax}</option>
                              <option value="1" ${valueAddedTax == 1 ? 'selected' : ''}>${translations.exempt_tax}</option>
                              <option value="2" ${valueAddedTax == 2 ? 'selected' : ''}>${translations.including_tax}</option>
                          </select>
                          <input type="number" hidden name="products[${rowIndex}][tax_amount]" class="form-control form-control-sm tax_amount w-auto" value="0" min="0" step="any">
                      </td>

                      <td>
                          <input type="number" name="products[${rowIndex}][total]" class="form-control form-control-sm total w-auto" value="0" readonly step="any">
                          <input type="number" hidden name="products[${rowIndex}][product_id]" class="form-control form-control-sm total" value="${productId}">
                      </td>
                      <td>
                          <button type="button" class="btn btn-danger btn-sm remove-product">${translations.remove}</button>
                      </td>
                  </tr>
                  `;


                    $('#products_table tbody').append(rowHtml);
                    handleTaxCalculation();
                    rowIndex++;
                }

                calculateGrandTotal();
            });



            $('#products_table').on('input', '.quantity', function() {
                var row = $(this).closest('tr');
                var maxQty = parseFloat($(this).attr('max')) || Infinity;

                if ($(this).val() > maxQty) {
                    alert(`Maximum available quantity is ${maxQty}`);
                    $(this).val(maxQty);
                }

                calculateRowTotal(row);
            });


            $('#products_table').on('input', '.quantity', function() {
                var row = $(this).closest('tr');
                var maxQty = parseFloat($(this).attr('max')) || Infinity;

                if ($(this).val() > maxQty) {
                    alert(`Maximum available quantity is ${maxQty}`);
                    $(this).val(maxQty);
                }

                calculateRowTotal(row);
            });


            $('#products_table').on('change', '.price_type', function() {
                var row = $(this).closest('tr');
                var productId = row.data('product-id');
                var selectedPriceType = $(this).val();
                var sectorPrice = $('option[value="' + productId + '"]').data('sectorprice');
                var wholesalePrice = $('option[value="' + productId + '"]').data('wholesaleprice');
                var selectedPrice = selectedPriceType === 'sector' ? sectorPrice : wholesalePrice;

                row.find(`input[name="products[${row.data('index')}][product_price]"]`).val(selectedPrice);
                handleTaxCalculation();
            });

            $('#products_table').on('input', '.price, .quantity, .discount, .tax_amount', function() {
                var row = $(this).closest('tr');
                handleTaxCalculation();
            });

            $('#products_table').on('change', '.tax_type', function() {
                var row = $(this).closest('tr');
                var taxAmountField = row.find(`input[name="products[${row.data('index')}][tax_amount]"]`);
                if ($(this).is(':checked')) {
                    flag = 1;
                } else {
                    flag = 0;

                }
                handleTaxCalculation(flag);
            });

            $('#products_table').on('change', '.discount_type', function() {
                var row = $(this).closest('tr');
                calculateRowTotal(row);
            });

            $('#discount_application').on('change', function() {
                $('#products_table tbody tr').each(function() {
                    calculateRowTotal($(this));
                });
                calculateGrandTotal();
            });

            $('#discount_type, #discount_value').on('change', function() {
                calculateGrandTotal();
            });

            $('#extra_type, #extra_value').on('change', function() {
                calculateGrandTotal();
            });

            $('#products_table').on('click', '.remove-product', function() {
                $(this).closest('tr').remove();
                calculateGrandTotal();
                reindexRows();
            });

            function reindexRows() {
                $('#products_table tbody tr').each(function(index) {
                    $(this).data('index', index);
                    $(this).find('input, select').each(function() {
                        var name = $(this).attr('name');
                        if (name) {
                            var newName = name.replace(/\[\d+\]/, `[${index}]`);
                            $(this).attr('name', newName);
                        }
                    });
                });
                rowIndex = $('#products_table tbody tr').length;
            }

            handleTaxCalculation(); // Initial call to set the correct tax logic
        });
    </script>
@endsection
